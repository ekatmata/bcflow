  
// export default createTreeData  (data) {
//     let tree = [];
//     if(Array.isArray(data)){
//         data.sort(function (a, b) {
//             return a.ruleId - b.ruleId;
//         });
//     }
//    console.log(data); 
//     data.forEach(item => {
//         if (item.parentId == 0) {
     
//             tree.push(this.createObj(item));
//         } 
//     })

//     data.forEach(ele => {
//         if(ele.parentId == 0) return;
//         this.addChildren(tree[0], ele)
//     })
  
// }

//  addChildren = (node, ele) =>{
//     if (node.id == ele.parentId){
//         node.children.push(this.createObj(ele));
//         return;
//     }
//     var total = node.children.length;
//     for (var i = 0; i < total; i++){
//         this.addChildren(node.children[i], ele);
//     }
//     return;
// }

//  createObj =(data)=> {
//     let obj1={}
//     if(data.parentId === 0){
//         obj1  = {
//             id: data.ruleId,
//             label: data.nodeName,
//             expanded: true,
//             nodeid:"root",
//             workflowId:data.workFlowId,
//             children: []
//         }
//     }
//     else{
//   obj1 = {
//         id: data.ruleId,
//         label: data.nodeName,
//         action: data.action,
//         condition: data.condition,
//         expanded: true,
//         nodeid:"child",
//         workflowId:data.workFlowId,
//         children: []
//     }
// }
//     return obj1;
// }


export const getAuthHeader = () => {
    const header = {
        headers: { 
            Authorization: "Bearer " + "config.TOKEN",
            'Content-Type': 'application/json'
        }
    };
    return header;
}

export const setError = (context,name, error, callback) => {
    context.setState({ [name]: { ...context.state[name], error } }, callback && callback);
}

export const onChange = (context, name, newValue, callback) => {

    context.setState({ [name]: { ...context.state[name], value: newValue } }, callback && callback);
}

export const setOptions = (context, name, value, callback) => {
    context.setState({ [name]: { ...context.state[name], options: value } }, callback && callback);
}
export const savedActionData = (data) => {
console.log(data)
    return data;
}


export const showErrorMessage = (context, message) => {
    context.current.show({severity:'error', summary: 'Error', detail: `${message ? message : 'Some Server Error'}`, life: 3000})
}

export const showSucessMessage = (context, message) => {
    context.current.show({severity:'success', summary: 'Suceess', detail:`${message ? message :'Data saved successfully'}`, life: 3000})
}

export const setBreadCurmb = (link, label, state, auth, dispatch, callback) => {
    let breadCurmbItems = [...auth.breadCurmbItems];
    if(breadCurmbItems.some((item) => item.label === label)){
        return;
    }
    breadCurmbItems.push({ link, label, state });
    dispatch(callback({ breadCurmbItems }));
}

export const setHeader = (name, dispatch, callback) => {
    dispatch(callback({screenName : name}));
}