import axios from 'axios';

const uploadFile = async (formData) => {
  return new Promise((resolve, reject) => {
    axios.post(process.env.REACT_APP_SERVER_URL + `/uploadFiles`, formData)
      .then((res) => resolve(res.data))
      .catch(e => reject(e))
  })
}

const searchFile = async (filePath) => {
  return new Promise((resolve, reject) => {
    axios.get(process.env.REACT_APP_SERVER_URL + `/downFileList?filePath=${filePath}`)
      .then((res) => resolve(res.data))
      .catch(e => reject(e))
  })
}

const download = async (filePath, fileName) => {
  return new Promise((resolve, reject) => {
    axios.get(process.env.REACT_APP_SERVER_URL + `/downloadFile?filePath=${filePath}&fileName=${fileName}`)
      .then((res) => resolve(res.data))
      .catch(e => reject(e))
  })
}

export { uploadFile , searchFile, download}