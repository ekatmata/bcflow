import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Switch, Route, Link, Redirect } from 'react-router-dom';
// import ValidationRules from './components/common/validationRules';
//import ValidationRules from './components/validation-rules/validationRules';
import FileUpload from './components/bsflow-fileupload/fileUpload';
import FileDownload from './components/bsflow-filedownload/fileDownload';
import 'primereact/resources/themes/saga-blue/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';
import 'primeflex/primeflex.css';
import Header from './components/common/header'

function App() {
  return (
    <div className="App">
      <Header></Header>
      <BrowserRouter basename={''}>
        <Switch>
          <Route exact path="/" component={FileUpload} />
          <Route exact path="/download" component={FileDownload} />
          <Route exact path="*" component={FileUpload} />
        </Switch>
      </BrowserRouter>
    </div>
  );
}

export default App;
