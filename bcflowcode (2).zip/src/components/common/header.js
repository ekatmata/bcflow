import React, { Component } from 'react';
import '../../styles/index.css';
// import logo '../../assets/IDFC_logo.svg';
import logo from '../../assets/IDFC_logo.svg';
import { Sidebar } from 'primereact/sidebar';




const Header = (props) =>  {

    
    const onClick = () => {
        localStorage.removeItem('token');
        localStorage.removeItem('role');
        localStorage.removeItem('isWorkflow');
        window.location.href = '/login';
    }

        return (


            <div className="row full-width px-0 mx-0">
                <div className="col-md-12 px-0">
                    <div className="header-wrapper">
                        <div className="app-logo">
                            <div className="logo-icon"><i className="pi pi-bars" onClick={() => this.setState({ visibleLeftPanel: true })}></i> </div>
                            <div><img src={logo}></img></div>
                        </div>
                        <div className="app-menu text-center">
                            <span className="user text-center">BC FLOW File Upload</span>
                        </div>
                       {/* <div className="app-menu text-right">
                            <span className="user"><i className="pi pi-user"></i></span>
                            <span className="user">BUAdmin</span>
                            <span className="user cursor-pointer" ><i className="pi pi-sign-out"></i></span>
                        </div> */}
                        <div className="app-userinfo"></div>
                    </div>
                    {/* <Sidebar visible={this.state.visibleLeftPanel} onHide={() => this.setState({ visibleLeftPanel: false })}>
                        <div className="sidebar-info">
                            <div classNmae="menu-items"><a href="/home" className="header-list">Create Workflow</a></div>
                            <div classNmae="menu-items"><a href="/viewworkflow" className="header-list">View Workflow</a></div>
                            <div classNmae="menu-items"><a href="/action" className="header-list">Create Action</a></div>
                        </div>
                    </Sidebar> */}
                </div>
            </div>

        );
}


export default Header