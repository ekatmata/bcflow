import React, { Component, createRef } from 'react';
import { Dropdown } from 'primereact/dropdown';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from 'primereact/button';
import { InputText } from 'primereact/inputtext';
import { Link } from 'react-router-dom';
import { Toast } from 'primereact/toast';
import {
    uploadFile,
} from '../../service/bcflowFileUploadService';


export default class FileUpload extends Component {
    constructor(props) {
        super(props);

        this.state = {
            showzipupload: false,
            selectedStagename: '',
            selectedFile: null,
            selectedZipFile: null,
            stageName: [{
                stageName: 'clientevaluation',
                id: 1
            },
            {
                stageName: 'CancelSanction',
                id: 2
            },
            {
                stageName: 'Centre Trasfer',
                id: 3
            },
            {
                stageName: 'DateChange',
                id: 4
            }, {
                stageName: 'MobileNumberUpdate',
                id: 5
            }, {
                stageName: 'MobileUpdateReason',
                id: 6
            },
            {
                stageName: 'Sourcing',
                id: 7
            }]
        }
        this.stageNameChange = this.stageNameChange.bind(this)
        this.onFileChange = this.onFileChange.bind(this)
        this.onZipFileChange = this.onZipFileChange.bind(this)
    }
    stageNameChange(event) {
       
        this.setState({
            selectedStagename: event.value.stageName,
           
        })
        if (event.value.stageName === 'Sourcing') {
            this.setState({
                showzipupload: true
            })
        }
        else {
            this.setState({
                showzipupload: false
            })
        }

    }
    showError = () => {
        this.toast.show({ severity: 'error', summary: 'Error Message', detail: 'Please select required fields.', life: 3000 });
    }
    showApiError = () => {
        this.toast.show({severity:'error', summary: 'Error Message', detail:'File Upload Failed', life: 3000});
    }
    showZipValidationError = () => {
        this.toast.show({severity:'error', summary: 'Error Message', detail:'Please select a zip file', life: 3000});
    }
    showSuccess = () => {
        this.toast.show({severity:'success', summary: 'Success Message', detail:'File Uploaded Sucessfully', life: 3000});
    }
    onFileChange(event) {
       
        this.setState({
            selectedFile: event.target.files[0]
        })
    }
    onZipFileChange(event) {
       
        if(event.target.files[0].type === 'application/zip' || event.target.files[0].type === 'application/x-zip-compressed' || event.target.files[0].type === 'application/x-7z-compressed'){
        this.setState({
            selectedZipFile: event.target.files[0]
        })
    }
    else{
this.showZipValidationError()
    }
    }
    uploadFile() {
      
        if (this.state.selectedStagename === '' && this.state.selectedFile === null) {
            this.showError()
        }
        else if (this.state.selectedStagename !== '' && this.state.selectedFile === null) {
            this.showError()
        }
        else {
            if (this.state.selectedStagename === 'Sourcing' && this.state.selectedZipFile === null) {
                this.showError()
            }
            else {

               
                let formData = new FormData();

                // Update the formData object
                formData.append(
                    "file",
                    this.state.selectedFile,
                );
                formData.append(
                    "stageName",
                    this.state.selectedStagename,
                );
                if (this.state.selectedStagename === 'Sourcing' && this.state.selectedZipFile !== null) {
                    formData.append(
                        "documentsZip",
                        this.state.selectedZipFile,
                    );
                }
                else{

                }
               
             
                uploadFile(formData)
                    .then(res => {
                        //setPartners(res || []);
                       
                        if(res){
                            this.showSuccess()
                        }
                        else{
                         this.showApiError()  
                        }
                    })
            }
        }

    }
    navigateToDownload = (e) => {
        this.props.history.push('/download');
    }
    render() {
        return (
            <>
                <Toast ref={(el) => this.toast = el} />
                <div>
                    {/* <div className="rules-header">BC FLOW File Upload</div> */}
                    <div className="rules-wrapper">
                        <div className="val-row">
                            <div className="validator-type">
                                <label htmlFor="firstname5 " className=" dropdown-lebel ">Stage Name</label>
                                <div className="dropdown-wrapper" >
                                    <Dropdown
                                        className="dropdown-class"
                                        value={this.state.selectedStagename}
                                        options={this.state.stageName}
                                        onChange={this.stageNameChange}
                                        optionLabel="stageName"
                                        placeholder={this.state.selectedStagename} />

                                </div>
                                <div className="file-upload">

                                    <input type="file" onChange={this.onFileChange} />
                                </div>
                                {this.state.showzipupload &&
                                    <div>
                                        <label htmlFor="firstname5 " className="zip-lebel">Zip : </label>
                                        <input type="file" onChange={this.onZipFileChange} />
                                    </div>}
                            </div>
                        </div>
                        <div>
                            <button className="button-fileupload" onClick={(e) => this.uploadFile()}>Upload</button>
                            <button className="button-fileupload" onClick={(e) => this.navigateToDownload()}>Download Files</button>
                        </div>
                    </div>
                </div>
            </>
        )
    }
}