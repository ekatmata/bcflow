import React, { Component, createRef } from 'react';
import { Dropdown } from 'primereact/dropdown';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from 'primereact/button';
import { InputText } from 'primereact/inputtext';
import { Link } from 'react-router-dom';
import { Toast } from 'primereact/toast';
import {
    searchFile,download
} from '../../service/bcflowFileUploadService';


export default class FileUpload extends Component {
    constructor(props) {
        super(props);

        this.state = {
            pathNameValue: '',
            prevPath : '',
            files: []
        }
    }
    pathNameChange = (event) => {

        this.setState({
            pathNameValue: event.target.value,

        })
    }

    getFile = () => {
        const { pathNameValue } = this.state;
        searchFile(pathNameValue)
            .then(res => {
                let data = [];
                if(res.fileList){
                    data = res.fileList.map(item => {return {"fileName" : item}})
                    this.setState({
                        files: data,
                        prevPath : pathNameValue
                    })
                }
                
            }).catch(e => console.log(e));
    }

    showError = () => {
        this.toast.show({ severity: 'error', summary: 'Error Message', detail: 'Please select required fields.', life: 3000 });
    }
    showApiError = () => {
        this.toast.show({ severity: 'error', summary: 'Error Message', detail: 'File Upload Failed', life: 3000 });
    }
    showZipValidationError = () => {
        this.toast.show({ severity: 'error', summary: 'Error Message', detail: 'Please select a zip file', life: 3000 });
    }
    showSuccess = () => {
        this.toast.show({ severity: 'success', summary: 'Success Message', detail: 'File Uploaded Sucessfully', life: 3000 });
    }

    downloadFile = (rowData) => {
        console.log('rowData', rowData);
        const {prevPath} = this.state;
        download(prevPath, rowData.fileName)
            .then(blob => {
                const url = window.URL.createObjectURL(
                    new Blob([blob]),
                  );
                  const link = document.createElement('a');
                  link.href = url;
                  link.setAttribute(
                    'download',
                    `${rowData.fileName}`,
                  );
                  document.body.appendChild(link);              
                  link.click();              
                  link.parentNode.removeChild(link);
            }).catch(e => console.log(e));
    }

    actionBodyTemplate = (rowData) => {
        return <a href="#" download onClick={(e) => { e.preventDefault(); this.downloadFile(rowData) }}>Download</a>;
    }

    render() {
        return (
            <>
                <Toast ref={(el) => this.toast = el} />
                <div>
                    {/* <div className="rules-header">BC FLOW File Upload</div> */}
                    <div className="rules-wrapper">
                        <div className="val-row">
                            <div className="validator-type">
                                <label htmlFor="firstname5 " className=" dropdown-lebel ">File Path Name</label>
                                <div className="dropdown-wrapper" >
                                    <InputText
                                        className="dropdown-class"
                                        value={this.state.pathNameValue}
                                        onChange={this.pathNameChange}
                                        placeholder={this.state.selectedStagename} />

                                </div>
                                <div className="file-upload">
                                    <Button label='Submit' onClick={this.getFile} />
                                </div>
                            </div>

                        </div>
                        <div className="card table-m">
                            <DataTable header={'Files for download'} value={this.state.files} responsiveLayout="scroll" stripedRows paginator
                                paginatorTemplate="CurrentPageReport FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink"
                                currentPageReportTemplate="Showing {first} to {last} of {totalRecords}" rows={10}>
                                <Column field="fileName" header="File Name"></Column>
                                <Column header="Action" body={this.actionBodyTemplate}></Column>
                            </DataTable>
                        </div>
                    </div>
                </div>
            </>
        )
    }
}